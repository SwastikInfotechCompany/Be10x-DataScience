# AI-Augmented Industrial Data Analytics & Predictive Modeling

A production-grade reference project for industrial data analytics, predictive modeling with supervised learning, and automated data reporting.

---

## 🎯 Part 1: Predictive Analytics with Supervised Learning

Part 1 implements an end-to-end supervised machine learning pipeline designed to train a corporate compensation model on real-world "dirty" HR records, enforce rigorous data hygiene, evaluate generalization error, and deliver a certified **Salary Prediction Audit**.

### Implementation Guide & Industrial Architecture

| Topic / Skill | Implementation in Pipeline | Real-World Industrial Use Case |
| :--- | :--- | :--- |
| **Data Hygiene & Cleaning** | 1. Purges duplicates (`drop_duplicates`)<br>2. Imputes missing entries using **Column Median Filling** (`fillna(median)`)<br>3. Eliminates unrealistic **Outliers** via domain limits and statistical IQR bounds ($Q1 - 1.5 \times IQR$ to $Q3 + 1.5 \times IQR$). | Cleans raw HR system exports to prevent salary predictions from being skewed by typos, fake entries, or missing data. |
| **Linear Regression Modeling** | Applies $Y = MX + C$:<br>• $X$ = Years of Experience<br>• $Y$ = Annual Compensation (USD)<br>• $M$ = Marginal salary gain per year of experience<br>• $C$ = Base starting salary | Provides an explainable HR compensation engine that prices new hires equitably based on verified market experience. |
| **Error Metrics & Evaluation** | Computes **MAE**, **MSE**, **RMSE**, and **$R^2$ Score**.<br>Validates against the corporate 95% budget accuracy benchmark ($R^2 \ge 0.95$). | Determines whether an ML compensation model is statistically sound before committing corporate hiring budgets. |

---

## 📋 Part 1 Deliverable: Salary Prediction Audit Summary

- **Target Candidate**: Candidate with **15 Years of Experience** ($X = 15.0$)
- **Learned Regression Equation**:
  $$\text{Salary} = 5,176.59 \times \text{Experience} + 48,024.45$$
- **Step-by-Step Calculation**:
  $$\text{Salary} = (5,176.59 \times 15.0) + 48,024.45 = \$125,673.29$$
- **Final Predicted Annual Salary**: **\$125,673.29**
- **Predicted Monthly Salary**: **\$10,472.77 / month**
- **95% Corporate Confidence Range**: **\$120,145.34 – \$131,201.23** (Margin of error: $\pm 1.96 \times \text{RMSE}$)
- **Model Evaluation Scores**:
  - **$R^2$ Score**: **0.9957 (99.57%)** (Exceeds the 95% corporate threshold — **PASSED**)
  - **Mean Absolute Error (MAE)**: **\$2,267.79**
  - **Root Mean Squared Error (RMSE)**: **\$2,820.38**
  - **Mean Squared Error (MSE)**: **7,954,566.08**
- **Data Hygiene Audit**:
  - Initial Raw Records: **165**
  - Duplicate Rows Dropped: **15**
  - Nulls Imputed (Median Filling): **8 Experience, 6 Rating, 6 Salary**
  - Unrealistic Outliers Eliminated: **9** (corrupt negative values, multi-million dollar typo outliers, micro salaries, impossible 85+ yr experience entries)
  - Final Certified Clean Records: **141** (85.45% retention)

---

## 🖥️ Interactive User Interface (UI) Options

To view, explore, and interact with the reports, multiple UI options are available:

### Option 1: Standalone HTML Dashboard (Zero Installation Required)
Simply double-click or open the generated file directly in any browser (Chrome, Edge, Firefox, Brave):
```
reports/salary_prediction_dashboard.html
```
- **Features**:
  - **Interactive Dynamic Slider**: Drag experience from 0 to 30 years to watch the predicted compensation, monthly salary, and 95% budget range update in real-time.
  - **Live Canvas/Chart.js Plot**: Watch the gold candidate star move along the regression trendline dynamically as you adjust experience.
  - **Data Hygiene Waterfall & Summary**: Visual cards detailing rows removed, median values imputed, and outlier filtering thresholds.
  - **Searchable Clean Dataset Explorer**: Instant search across all 141 verified records with residual error tracking.
  - **High-Res Visual Gallery**: View high-resolution Matplotlib audit plots.
  - **Print / Save as PDF**: One-click printable executive report.

### Option 2: Local Python Web UI Server (Built-in `http.server`)
Run the lightweight web server with live REST API endpoints:
```powershell
python src/salary_ui.py --port 8000
```
Open **`http://localhost:8000`** in your browser.
- Interactive endpoints available:
  - `GET /api/predict?experience=15.0`: returns live server-side salary prediction and budget interval.
  - `GET /api/audit`: returns the complete JSON audit metadata.

### Option 3: Streamlit Web Dashboard (Optional)
If Streamlit is installed:
```powershell
streamlit run src/salary_streamlit_app.py
```

---

## 🚀 How to Run the Pipeline

### 1. Install Dependencies
```powershell
python -m pip install -r requirements.txt
```

### 2. Run Part 1 Salary Prediction Pipeline
```powershell
# Run the complete cleaning, regression modeling, candidate prediction, and audit generation
python src/salary_prediction_project.py

# Run for a custom candidate experience (e.g. 18 years)
python src/salary_prediction_project.py --experience 18.0

# Run on a custom dataset
python src/salary_prediction_project.py --data-path "path/to/custom_dirty_data.csv"
```

### 3. Generated Part 1 Artifacts & UI Screenshots
All outputs and visual reports are saved to `reports/` and `ui_screenshots/`:
- **UI Screenshots (`ui_screenshots/`)**:
  - `01_full_dashboard_overview.png` – Master full-dashboard UI overview.
  - `02_interactive_candidate_predictor.png` – Interactive candidate predictor (15-yr deliverable calculation).
  - `03_data_hygiene_cleaning_funnel.png` – 3-step data hygiene pipeline funnel & boxplots.
  - `04_regression_trendline_chart.png` – Interactive regression fit with target candidate highlight.
  - `05_model_residuals_and_diagnostics.png` – Model residual error diagnostics & normality distribution.
  - `06_clean_dataset_table_explorer.png` – Certified clean dataset table explorer.
  - `07_salary_prediction_audit_report.png` – Executive salary prediction audit report deliverable.
- **Interactive Reports (`reports/`)**:
  - `reports/salary_prediction_dashboard.html` – Standalone interactive HTML browser dashboard.
  - `reports/salary_prediction_audit.json` – Machine-readable audit data with full metrics.
  - `reports/salary_prediction_audit.txt` – Formatted executive audit document.
  - `reports/cleaned_hr_dataset.csv` – Final hygiene-certified dataset.
  - `reports/salary_regression_plot.png` – Regression fit ($Y=MX+C$) with candidate marker.
  - `reports/data_cleaning_audit.png` – Before-vs-after data hygiene distributions & funnel.
  - `reports/model_residuals_plot.png` – Error distribution & residual diagnostics.

---

## 📦 Additional Project Components

- `src/performance_audit.py` – Benchmarks a 10% salary increase across one million salaries using Python lists vs. NumPy arrays.
- `src/retail_dashboard.py` – Cleans and joins ShopEase Orders, Products, and Customers to generate annual retail analytics and charts.
- `data/` – Contains dataset files (`dirty_hr_dataset.csv`, `orders.csv`, `products.csv`, `customers.csv`).
