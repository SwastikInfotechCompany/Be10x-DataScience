"""
Salary Prediction UI Server
===========================
Lightweight zero-dependency web server built on Python standard library http.server.
Serves the Part 1 HR Salary Prediction Audit Dashboard with interactive API endpoints.

Usage:
  python src/salary_ui.py [--port 8000]
"""

import os
import sys
import json
import urllib.parse
from http.server import HTTPServer, SimpleHTTPRequestHandler

PORT = 8000
REPORTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "reports"))
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))

class SalaryDashboardHandler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        # Serve static assets from reports directory or data directory
        clean_path = path.split('?', 1)[0].split('#', 1)[0]
        if clean_path in ['/', '/index.html', '/dashboard']:
            return os.path.join(REPORTS_DIR, 'salary_prediction_dashboard.html')
        
        target = os.path.join(REPORTS_DIR, clean_path.lstrip('/'))
        if os.path.exists(target):
            return target
            
        target_data = os.path.join(DATA_DIR, clean_path.lstrip('/'))
        if os.path.exists(target_data):
            return target_data
            
        return super().translate_path(path)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        
        # API 1: /api/audit
        if parsed.path == '/api/audit':
            audit_file = os.path.join(REPORTS_DIR, 'salary_prediction_audit.json')
            if os.path.exists(audit_file):
                with open(audit_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self.send_json_response(data)
            else:
                self.send_json_response({'error': 'Audit report not generated yet. Run salary_prediction_project.py first.'}, status=404)
            return

        # API 2: /api/predict?experience=15.0&rating=4.0
        elif parsed.path == '/api/predict':
            query = urllib.parse.parse_qs(parsed.query)
            try:
                exp = float(query.get('experience', [15.0])[0])
            except ValueError:
                exp = 15.0
            
            audit_file = os.path.join(REPORTS_DIR, 'salary_prediction_audit.json')
            if os.path.exists(audit_file):
                with open(audit_file, 'r', encoding='utf-8') as f:
                    audit = json.load(f)
                slope = audit['model_results']['slope_m']
                intercept = audit['model_results']['intercept_c']
                rmse = audit['model_results']['metrics']['rmse']
                
                pred_sal = (slope * exp) + intercept
                margin = 1.96 * rmse
                
                resp = {
                    'experience_years': exp,
                    'predicted_annual_salary': round(pred_sal, 2),
                    'predicted_monthly_salary': round(pred_sal / 12.0, 2),
                    'confidence_interval_95': {
                        'min': round(max(0, pred_sal - margin), 2),
                        'max': round(pred_sal + margin, 2)
                    },
                    'equation_used': f"Y = ({slope:,.2f} * {exp}) + {intercept:,.2f}"
                }
                self.send_json_response(resp)
            else:
                self.send_json_response({'error': 'Model not trained yet.'}, status=404)
            return

        # Default: Serve static files
        super().do_GET()

    def send_json_response(self, data, status=200):
        body = json.dumps(data, indent=2).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        # Concise logging
        sys.stderr.write(f"[Salary UI Server] {self.address_string()} - {args[0]} {args[1]}\n")

def launch_ui_server(port=PORT, reports_dir=None):
    global REPORTS_DIR
    if reports_dir:
        REPORTS_DIR = os.path.abspath(reports_dir)
        
    dashboard_file = os.path.join(REPORTS_DIR, 'salary_prediction_dashboard.html')
    if not os.path.exists(dashboard_file):
        print(f"[Warning] Dashboard file not found at {dashboard_file}. Running pipeline to generate it...")
        from salary_prediction_project import run_salary_pipeline
        run_salary_pipeline(output_dir=REPORTS_DIR)
        
    server_address = ('', port)
    httpd = HTTPServer(server_address, SalaryDashboardHandler)
    print("\n" + "=" * 70)
    print(f"🚀 SALARY PREDICTION AUDIT UI SERVER RUNNING")
    print(f"👉 Local URL: http://localhost:{port}")
    print(f"👉 Dashboard File: {dashboard_file}")
    print(f"Press Ctrl+C to stop the server.")
    print("=" * 70 + "\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down Salary UI Server...")
        httpd.server_close()

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description="Launch Salary Prediction UI Dashboard Server")
    parser.add_argument('--port', type=int, default=PORT, help='Port to bind the web server (default: 8000)')
    parser.add_argument('--reports-dir', type=str, default=REPORTS_DIR, help='Path to reports directory')
    args = parser.parse_args()
    
    launch_ui_server(port=args.port, reports_dir=args.reports_dir)
